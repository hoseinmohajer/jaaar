<?php
class Jaaar extends AppModel{
	var $name = 'jaaar';
}


?>